﻿using Microsoft.EntityFrameworkCore;
using Session2.Models;

namespace Session2.Data
{
    public class DepartmentContext :DbContext
    {
        public DbSet<Department> Departments { get; set; }  
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
           optionsBuilder.UseSqlServer("Server=db5021.databaseasp.net; Database=db5021; User Id=db5021; Password=nP@4-8Qq7h?D; Encrypt=False; MultipleActiveResultSets=True;");
        }
    }
}
